"""
Validates required fields in input data.
"""

def validate_fields(required_fields, data):
    missing = [field for field in required_fields if field not in data or not data[field]]
    if missing:
        return {"status": "error", "missing_fields": missing}
    return {"status": "ok"}
