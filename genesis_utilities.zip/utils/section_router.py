"""
Routes input data to the appropriate Genesis module.
"""

def route_data(section_name, input_data):
    from modules import gds, adjuster_questions, rrt, decision_point, prophet

    section_map = {
        "GDS": gds.process,
        "AdjusterQuestions": adjuster_questions.process,
        "RRT": rrt.process,
        "DecisionPoint": decision_point.process,
        "Prophet": prophet.process
    }

    if section_name not in section_map:
        raise ValueError(f"Unknown section: {section_name}")
    
    return section_map[section_name](input_data)
