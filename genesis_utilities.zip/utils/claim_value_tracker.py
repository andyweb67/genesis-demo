"""
Tracks claim value through Genesis stages.
"""

class ClaimValueTracker:
    def __init__(self):
        self.values = {}

    def record(self, stage, amount):
        self.values[stage] = amount

    def summary(self):
        return {
            "initial_demand": self.values.get("initial"),
            "post_genesis": self.values.get("genesis"),
            "adjuster_offer": self.values.get("adjuster"),
            "final_demand": self.values.get("final"),
            "uplift_percent": self._calculate_uplift()
        }

    def _calculate_uplift(self):
        initial = self.values.get("initial")
        final = self.values.get("final")
        if initial and final:
            return round(((final - initial) / initial) * 100, 2)
        return None
