"""
Logs case-level metrics for audits or demos.
"""

import datetime
import json

def log_case_metrics(case_id, data, path="/data/metrics_log.jsonl"):
    entry = {
        "timestamp": str(datetime.datetime.now()),
        "case_id": case_id,
        **data
    }
    with open(path, "a") as f:
        f.write(json.dumps(entry) + "\n")
