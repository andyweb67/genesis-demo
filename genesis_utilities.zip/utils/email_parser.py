"""
Extracts adjuster replies from email threads.
"""

import re

def extract_adjuster_reply(email_text):
    cleaned = re.split(r"(From:|On .*wrote:)", email_text)[0]
    return cleaned.strip()
